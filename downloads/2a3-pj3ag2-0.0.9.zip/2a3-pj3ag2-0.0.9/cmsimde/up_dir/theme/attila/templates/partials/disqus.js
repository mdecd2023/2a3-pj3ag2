{% if DISQUS_SITENAME %}
<script type="text/javascript">
    var disqus_shortname = '{{ DISQUS_SITENAME }}';
    (function () {
        var s = document.createElement('script'); s.async = true;
        s.type = 'text/javascript';
        s.src = '//' + disqus_shortname + '.disqus.com/count.js';
        (document.getElementsByTagName('HEAD')[0] || document.getElementsByTagName('BODY')[0]).appendChild(s);
    }());
</script>
{% endif %}
