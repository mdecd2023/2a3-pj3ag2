function for1()
    return [[
x = 1

for i = 1, 11, 2 do
  x = x * i
  print(x)
end
    ]]
end